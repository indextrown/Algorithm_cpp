#include "QTViewer.h"

QTViewer::QTViewer(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

QTViewer::~QTViewer()
{}
