/********************************************************************************
** Form generated from reading UI file 'QTViewer.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTVIEWER_H
#define UI_QTVIEWER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "viewer.h"

QT_BEGIN_NAMESPACE

class Ui_QTViewerClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    Viewer *openGLWidget;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QTViewerClass)
    {
        if (QTViewerClass->objectName().isEmpty())
            QTViewerClass->setObjectName("QTViewerClass");
        QTViewerClass->resize(1101, 901);
        centralWidget = new QWidget(QTViewerClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        openGLWidget = new Viewer(centralWidget);
        openGLWidget->setObjectName("openGLWidget");

        gridLayout->addWidget(openGLWidget, 0, 0, 1, 1);

        QTViewerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QTViewerClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 1101, 21));
        QTViewerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QTViewerClass);
        mainToolBar->setObjectName("mainToolBar");
        QTViewerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QTViewerClass);
        statusBar->setObjectName("statusBar");
        QTViewerClass->setStatusBar(statusBar);

        retranslateUi(QTViewerClass);

        QMetaObject::connectSlotsByName(QTViewerClass);
    } // setupUi

    void retranslateUi(QMainWindow *QTViewerClass)
    {
        QTViewerClass->setWindowTitle(QCoreApplication::translate("QTViewerClass", "QTViewer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QTViewerClass: public Ui_QTViewerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTVIEWER_H
